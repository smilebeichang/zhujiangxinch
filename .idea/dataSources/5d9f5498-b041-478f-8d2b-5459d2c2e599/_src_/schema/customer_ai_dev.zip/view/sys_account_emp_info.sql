CREATE VIEW sys_account_emp_info AS
  SELECT
    `a`.`ACCOUNT_CODE`        AS `ACCOUNT_CODE`,
    `a`.`CTIPHONE`            AS `CTIPHONE`,
    `a`.`AGENT_ID`            AS `AGENT_ID`,
    `b`.`NAME`                AS `emp_name`,
    `b`.`ORG_CODE`            AS `ORG_CODE`,
    `a`.`SKILL_GROUP_CODE`    AS `SKILL_GROUP_CODE`,
    `a`.`BUSINESS_GROUP_CODE` AS `BUSINESS_GROUP_CODE`,
    `a`.`OPERATOR_TYPE_CODE`  AS `OPERATOR_TYPE_CODE`,
    `c`.`VALUE`               AS `value`
  FROM ((`customer_ai_dev`.`sys_account_info` `a` LEFT JOIN `customer_ai_dev`.`emp_base_info` `b`
      ON ((`a`.`EMP_CODE` = `b`.`CODE`))) LEFT JOIN `customer_ai_dev`.`sys_dictionary_info` `c`
      ON (((`a`.`BUSINESS_GROUP_CODE` = `c`.`CODE`) AND (`c`.`CODE_PATH` = 'root/BusinessPara/UOMP/BusinessGroup'))));
