CREATE VIEW v_uomp_qc_audio_query_z AS
  SELECT
    `a`.`CUST_NAME`                                         AS `CUST_NAME`,
    `a`.`CUST_PHONE`                                        AS `CUST_PHONE`,
    `a`.`ROOM_NO`                                           AS `unique_serial_no`,
    `a`.`ROOM_NO`                                           AS `param`,
    `b`.`BEGIN_TIME`                                        AS `call_date`,
    `b`.`END_TIME`                                          AS `answer_date`,
    `b`.`ACCOUNT_CODE`                                      AS `parter_code`,
    `a`.`CHANNEL_NO`                                        AS `CHANNEL_NO`,
    `b`.`SATISFACTION`                                      AS `SATISFACTION`,
    `b`.`MESSAGE_NUM`                                       AS `MESSAGE_NUM`,
    timestampdiff(SECOND, `b`.`BEGIN_TIME`, `b`.`END_TIME`) AS `talk_seconds`
  FROM (`customer_ai_dev`.`ochat_log_queue_info` `a`
    JOIN `customer_ai_dev`.`ochat_log_room` `b`)
  WHERE ((`a`.`ROOM_NO` = `b`.`ROOM_NO`) AND (`a`.`ROOM_NO` IS NOT NULL) AND (`b`.`END_TIME` IS NOT NULL) AND
         (`b`.`ACCOUNT_CODE` IS NOT NULL) AND
         (NOT (`a`.`ROOM_NO` IN (SELECT `customer_ai_dev`.`uomp_qc_task_record`.`UNIQUE_SERIAL_NO`
                                 FROM `customer_ai_dev`.`uomp_qc_task_record`))));
