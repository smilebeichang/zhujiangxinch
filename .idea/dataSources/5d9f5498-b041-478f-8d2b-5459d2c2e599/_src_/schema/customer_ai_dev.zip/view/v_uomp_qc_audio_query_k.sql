CREATE VIEW v_uomp_qc_audio_query_k AS
  SELECT
    `k`.`SUM_NO`                                              AS `sum_no`,
    `k`.`CONNECT_ID`                                          AS `connect_id`,
    `k`.`CALL_CUST_NAME`                                      AS `cust_name`,
    `k`.`CALL_NO`                                             AS `call_no`,
    `k`.`CALL_TYPE`                                           AS `call_type`,
    `k`.`ACCOUNT_CODE`                                        AS `account_code`,
    `k`.`PARAM`                                               AS `PARAM`,
    str_to_date(`k`.`TSPICKTIME`, '%Y%m%d%H%i%s')             AS `answer_date`,
    str_to_date(`k`.`TSRINGTIME`, '%Y%m%d%H%i%s')             AS `call_date`,
    timestampdiff(SECOND, `k`.`TSPICKTIME`, `k`.`TSHANGTIME`) AS `talk_seconds`
  FROM `customer_ai_dev`.`log_call_info` `k`
  WHERE ((`k`.`TSPICKTIME` IS NOT NULL) AND (`k`.`PARAM` IS NOT NULL) AND (`k`.`TSHANGTIME` IS NOT NULL) AND
         (`k`.`ACCOUNT_CODE` IS NOT NULL) AND
         (NOT (`k`.`CONNECT_ID` IN (SELECT `customer_ai_dev`.`uomp_qc_task_record`.`UNIQUE_SERIAL_NO`
                                    FROM `customer_ai_dev`.`uomp_qc_task_record`))));
