CREATE VIEW v_uomp_qc_audio_query_c AS
  SELECT
    `ws`.`SUM_NO`                                               AS `sum_no`,
    `ws`.`CONNECT_ID`                                           AS `connect_id`,
    `ws`.`CUST_NAME`                                            AS `cust_name`,
    `ws`.`CALL_NO`                                              AS `call_no`,
    `ws`.`CALL_TYPE`                                            AS `call_type`,
    `ws`.`ACCOUNT_CODE`                                         AS `account_code`,
    `ws`.`SERVICE_TYPE`                                         AS `service_type`,
    `ws`.`PARAM`                                                AS `PARAM`,
    str_to_date(`ws`.`TSPICKTIME`, '%Y%m%d%H%i%s')              AS `answer_date`,
    str_to_date(`ws`.`TSRINGTIME`, '%Y%m%d%H%i%s')              AS `call_date`,
    timestampdiff(SECOND, `ws`.`TSPICKTIME`, `ws`.`TSHANGTIME`) AS `talk_seconds`
  FROM `customer_ai_dev`.`log_call_worksum_outer` `ws`
  WHERE ((`ws`.`TSPICKTIME` IS NOT NULL) AND (`ws`.`PARAM` IS NOT NULL) AND (`ws`.`TSHANGTIME` IS NOT NULL) AND
         (`ws`.`ACCOUNT_CODE` IS NOT NULL) AND
         (NOT (`ws`.`CONNECT_ID` IN (SELECT `customer_ai_dev`.`uomp_qc_task_record`.`UNIQUE_SERIAL_NO`
                                     FROM `customer_ai_dev`.`uomp_qc_task_record`))));
