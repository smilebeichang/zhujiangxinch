CREATE VIEW user_code_shift_name AS
  SELECT
    `a`.`ACCOUNT_CODE` AS `account_code`,
    `b`.`NAME`         AS `NAME`,
    `c`.`VALUE`        AS `skill`
  FROM ((`customer_ai_dev`.`sys_account_info` `a` LEFT JOIN `customer_ai_dev`.`emp_base_info` `b`
      ON ((`a`.`EMP_CODE` = `b`.`CODE`))) LEFT JOIN `customer_ai_dev`.`sys_dictionary_info` `c`
      ON ((`a`.`SKILL_GROUP_CODE` = `c`.`CODE`)))
  WHERE (`c`.`CODE_PATH` = 'root/BusinessPara/UOMP/SkillGroup');
