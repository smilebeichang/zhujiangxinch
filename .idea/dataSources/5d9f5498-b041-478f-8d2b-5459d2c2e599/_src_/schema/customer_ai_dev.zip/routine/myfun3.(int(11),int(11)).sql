CREATE FUNCTION myfun3(ia INT, ib INT)
  RETURNS INT
  begin
		DECLARE str varchar(4000);  
        DECLARE cid varchar(4000);   
        DECLARE area_id_str varchar(8000);
       
        SET GLOBAL group_concat_max_len=102400;
        SET SESSION group_concat_max_len=102400;
    return ia + ib;
end;
